import sys
from st2common.runners.base_action import Action
import lib
from hivecrypt import decrypt_secret
class AssignTicket(Action):
    def run(self, PASSWORD):

        if PASSWORD.startswith("enc://"):
            PASSWORD = decrypt_secret(PASSWORD)
        else:
            PASSWORD = PASSWORD
        return PASSWORD
