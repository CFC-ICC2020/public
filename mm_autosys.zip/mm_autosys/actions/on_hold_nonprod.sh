#!/bin/sh
job=$1
job_status=$((. /opt/CA/WorkloadAutomationAE/autouser.POC/autosys.sh.rpgdevlx001 && autorep -j $job) 2>&1)
output=""
check_job=0
for i in $job_status;do
    if [[ $i == "FA" || $i == "SU" || $i == "TE" || $i == "OH" || $i == "OI" || $i == "AC" || $i == "IN" ]]; then
        output+="JOB STATUS BEFORE ACTIVITY:\n$job_status\n"
        hold_status=$((. /opt/CA/WorkloadAutomationAE/autouser.POC/autosys.sh.rpgdevlx001 && sendevent -E JOB_ON_HOLD -J $job) 2>&1)
        if [ -z $hold_status ];then
            output+="JOB PUT TO ON-HOLD COMMAND EXECUTED SUCCESSFULLY.\n"
            final_status=$((. /opt/CA/WorkloadAutomationAE/autouser.POC/autosys.sh.rpgdevlx001 && autorep -j $job) 2>&1)
            check_status=0
            for j in $final_status;do
                if [[ $j == "OH" ]];then
                    output+="JOB PUT TO ON-HOLD SUCCESSFULLY.\n$final_status\n"
                    check_status=1
                fi
            done
            if [[ $check_status == 0 ]];then
                output+="ERROR: PUTTING ON-HOLD FAILED. STATUS AFTER PUTTING ON-HOLD:\n$final_status\n"
            fi
        else
            output+="ERROR: PUTTING ON HOLD COMMAND EXECUTION FAILED.\n$hold_status\n"
        fi
        check_job=1
    fi
done
if [[ $check_job == 0 ]];then
    output+="ERROR: JOB IN STARTING OR RUNNING STATE.\n$job_status\n"
fi
echo -e $output
